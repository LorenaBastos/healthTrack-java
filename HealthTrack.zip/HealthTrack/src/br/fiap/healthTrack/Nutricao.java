package br.fiap.healthTrack;

import javax.swing.JOptionPane;

/*  A classe Nutricao armazena as informa��es de dieta, almoco, cafe da manh� e janta
 */
public class Nutricao {
	protected String dieta;
	protected String cafeManha;
	protected String almoco;
	protected String janta;
	Refeicao TipoDeRefeicao = new Refeicao();
	
/* O met�do adicionarDietas() recebe a informa��o de dieta escolhida e devolve a informa��o
 */
	public void adicionarDietas() {
		dieta = JOptionPane.showInputDialog("Digite a dieta escolhida");
		System.out.println("Foi adicionado a dieta " + dieta);
	}
	/* O met�do adicionarAlmoco() recebe a informa��o de almo�o  e devolve a informa��o
	 */
	public void adicionarAlmoco() {
		almoco = JOptionPane.showInputDialog("Digite o seu almoco");
		System.out.println("Foi adicionado " + almoco);
	}
	/* O met�do adicionarCafeManha() recebe a informa��o de caf� da manh� devolve a informa��o
	 */
	public void adicionarCafeManha() {
		cafeManha = JOptionPane.showInputDialog("Digite o seu caf� da manh�");
		System.out.println("Foi adicionado " + cafeManha);
	}
	/* O met�do adicionarJanta() recebe a informa��o de janta e devolve a informa��o
	 */
	public void adicionarJanta() {
		janta = JOptionPane.showInputDialog("Digite a sua janta");
		System.out.println("Foi adicionado " + janta);
	}
	
	public Refeicao getTipoDeRefeicao() {
		return TipoDeRefeicao;
	}

	public void setTipoDeRefeicao(Refeicao tipoDeRefeicao) {
		TipoDeRefeicao = tipoDeRefeicao;
	}
	
	public String getDieta() {
		return dieta;
	}
	public void setDietas(String dieta) {
		this.dieta = dieta;
	}
	public String getCafeManha() {
		return cafeManha;
	}
	public void setCafeManha(String cafeManha) {
		this.cafeManha = cafeManha;
	}
	public String getAlmoco() {
		return almoco;
	}
	public void setAlmoco(String almoco) {
		this.almoco = almoco;
	}
	public String getJanta() {
		return janta;
	}
	public void setJanta(String janta) {
		this.janta = janta;
	}
	
	
}
