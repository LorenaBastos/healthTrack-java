package br.fiap.healthTrack;

import javax.swing.JOptionPane;

/* A classe peso armazena as informa��es de descri��o do peso, quilos perdidos, total dos quilos perdidos e a data
 */
public class Peso {
	protected float descricaoPeso;
	protected float quilosPerdidos;
	protected float totalQuilosPerdidos;
	protected String dataPeso;
	
	
	public float getDescricaoPeso() {
		return descricaoPeso;
	}
	public void setdescricaoPeso(float descricaoPeso) {
		this.descricaoPeso = descricaoPeso;
	}
	public float getQuilosPerdidos() {
		return quilosPerdidos;
	}
	public void setQuilosPerdidos(float quilosPerdidos) {
		this.quilosPerdidos = quilosPerdidos;
	}
	public float getTotalQuilosPerdidos() {
		return totalQuilosPerdidos;
	}
	public void setTotalQuilosPerdidos(float totalQuilosPerdidos) {
		this.totalQuilosPerdidos = totalQuilosPerdidos;
	}
	public String getDataPeso() {
		return dataPeso;
	}
	public void setDataPeso(String dataPeso) {
		this.dataPeso = dataPeso;
	}
	
	/* O met�do CalcularPeso() recebe os dados de descricaoPeso, quilosPerdidos e calcula o total de quilos perdidos na vari�vel totalQuilosPerdidos
	 */
		public void calcularPeso() {
			descricaoPeso = Float.valueOf(JOptionPane.showInputDialog("Digite o seu peso"));
			quilosPerdidos = Float.valueOf(JOptionPane.showInputDialog("Digite o seu peso"));
			totalQuilosPerdidos = quilosPerdidos - descricaoPeso;
			System.out.println("Voce Perdeu " + totalQuilosPerdidos);
		}
	/*O met�do adicionarDataPeso recebe a informa��o de data do dia
	 */
		public void adicionarDataPeso() {
			dataPeso = JOptionPane.showInputDialog("Digite a data no formato dd/mm/aaaa");
			System.out.println("Foi adicionado a data " + dataPeso);
		}
}
