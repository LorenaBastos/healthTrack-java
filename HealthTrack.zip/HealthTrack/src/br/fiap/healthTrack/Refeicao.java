package br.fiap.healthTrack;

import javax.swing.JOptionPane;

/* A classe Refeicao armazena as informa��es do tipo de refeicao, quantidade de calorias e data de refeicao
 */
public class Refeicao {
	protected String tipoRefeicao;
	protected int qtdCalorias;
	protected String dataRefeicao;
	
	
	public String getTipoRefeicao() {
		return tipoRefeicao;
	}
	public void setTipoRefeicao(String tipoRefeicao) {
		this.tipoRefeicao = tipoRefeicao;
	}
	public int getQtdCalorias() {
		return qtdCalorias;
	}
	public void setQtdCalorias(int qtdCalorias) {
		this.qtdCalorias = qtdCalorias;
	}
	public String getDataRefeicao() {
		return dataRefeicao;
	}
	public void setDataRefeicao(String dataRefeicao) {
		this.dataRefeicao = dataRefeicao;
	}
	
	/* O met�do adicionarCalorias() recebe a quantidade de calorias	 */
	public void adicionarCalorias() {
		qtdCalorias = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de calorias "));
	}
	
	/*O met�do adicionarDataRefeicao recebe a informa��o de data do dia */
	
	public void adicionarDataRefeicao() {
		dataRefeicao = JOptionPane.showInputDialog("Digite a data no formato dd/mm/aaaa");
		System.out.println("Foi adicionado a data " + dataRefeicao);
	}
}
