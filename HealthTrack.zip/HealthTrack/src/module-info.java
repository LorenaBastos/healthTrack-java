module HealthTrack {
	requires java.desktop;
}